import os  # Dodany brakujący import
import pandas as pd
import numpy as np
from random import choice, randint
from datetime import datetime, timedelta

employees = ["Jan Kowalski", "Adam Nowak", "Justyna Kwiecień"]
years = [2012, 2013, 2014]
months = [1, 2, 3]
projects = ["Projekt 1", "Projekt 2"]

tasks = ["Development", "Scrum_meetings", "Bug_fixing", "Improvement", "Release"]
descriptions = ["Story", "Meeting", "Bug fix", "Release", "Improvement"]
priorities = ["#critical", "#important", "#normal", "#minor"]
labels = ["#sustaining", "#Release_May", "#Release_June", "#Release_July", "#Maintenance"]

def generate_task_description():
    task = choice(tasks)
    desc = choice(descriptions)

    if desc == "Story":
        desc += f" {randint(1, 5)}"
    elif desc == "Release":
        desc += f" {choice(['May', 'June', 'July'])}"

    return f"[{task}] {desc} {choice(priorities)} {choice(labels)}"

def generate_time():
    if np.random.random() < 0.8:
        return randint(1, 25)
    else:
        return randint(0, 24) + 0.5

def generate_month_data(year, month):
    start_date = datetime(year, month, 1)
    end_date = (datetime(year, month + 1, 1) - timedelta(days=1)) if month < 12 else datetime(year, 12, 31)

    return [{
        "Data": (start_date + timedelta(days=np.random.randint(0, (end_date - start_date).days))).strftime("%d.%m.%Y"),
        "Zadanie": generate_task_description(),
        "Czas[h]": generate_time()
    } for _ in range(20 + randint(0, 5))]

for year in years:
    for month in months:
        year_folder = str(year)
        month_folder = f"{month:02d}"
        os.makedirs(os.path.join(year_folder, month_folder), exist_ok=True)

        for employee in employees:
            last_name, first_name = employee.split()
            file_path = os.path.join(year_folder, month_folder, f"{last_name}_{first_name}.xlsx")

            with pd.ExcelWriter(file_path, engine='xlsxwriter') as writer:
                for project in projects:
                    df = pd.DataFrame(generate_month_data(year, month))
                    df.to_excel(writer, sheet_name=project, index=False)
